import Rentbook from "./components/Rentbook"

function App() {

	return (
		<Rentbook />
	)
};

export default App
