import Logbook from "./components/Logbook"

function App() {

    return (
        <Logbook />
    )
};

export default App
